from setuptools import setup

setup(
    name='diff_drive_sim',
    version='1.0.0',
    packages=['diff_drive_sim'],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Student',
    maintainer_email='student@example.com',
    description='Differential drive simulator with drawing',
    license='Apache License 2.0',
    entry_points={
        'console_scripts': [
            'diff_drive_sim_node = diff_drive_sim.diff_drive_sim_node:main',
            'drawing_node = diff_drive_sim.drawing_node:main',
        ],
    },
)