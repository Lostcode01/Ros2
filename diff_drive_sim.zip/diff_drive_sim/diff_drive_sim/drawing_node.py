import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib import style
import threading

class DrawingNode(Node):
    def __init__(self):
        super().__init__('drawing_node')
        self.x_data = [0.0]
        self.y_data = [0.0]
        
        # Setup plot
        style.use('fivethirtyeight')
        self.fig = plt.figure(figsize=(8, 6))
        self.ax = self.fig.add_subplot(1, 1, 1)
        self.ax.set_title('Robot Path (like turtlesim)')
        self.ax.set_xlabel('X Position (m)')
        self.ax.set_ylabel('Y Position (m)')
        self.ax.grid(True, linestyle='--', alpha=0.7)
        self.line, = self.ax.plot([], [], 'b-', linewidth=2.5, label='Robot Path')
        self.ax.plot(0, 0, 'go', markersize=10, label='Start Position')
        self.ax.legend(loc='best')
        
        # Set initial view limits
        self.ax.set_xlim(-2, 2)
        self.ax.set_ylim(-2, 2)
        
        # ROS subscription
        self.subscription = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_cb,
            10
        )
        self.get_logger().info('Drawing panel started - move robot with cmd_vel')
        
        # Start animation
        self.ani = animation.FuncAnimation(
            self.fig, 
            self.update_plot, 
            interval=100,
            blit=True
        )
        
        # Show plot without blocking ROS thread
        plt.ion()
        plt.show()

    def odom_cb(self, msg):
        # Append new position data
        self.x_data.append(msg.pose.pose.position.x)
        self.y_data.append(msg.pose.pose.position.y)
        
        # Auto-adjust view limits for better visualization
        if len(self.x_data) > 1:
            max_range = max(
                max(self.x_data) - min(self.x_data),
                max(self.y_data) - min(self.y_data),
                4.0  # Minimum view size
            ) / 2.0
            
            center_x = (max(self.x_data) + min(self.x_data)) / 2
            center_y = (max(self.y_data) + min(self.y_data)) / 2
            
            self.ax.set_xlim(center_x - max_range, center_x + max_range)
            self.ax.set_ylim(center_y - max_range, center_y + max_range)

    def update_plot(self, frame):
        self.line.set_data(self.x_data, self.y_data)
        return self.line,

def main(args=None):
    rclpy.init(args=args)
    drawing_node = DrawingNode()
    
    # Run ROS node in separate thread
    ros_thread = threading.Thread(
        target=rclpy.spin, 
        args=(drawing_node,),
        daemon=True
    )
    ros_thread.start()
    
    try:
        # Keep matplotlib window alive
        while plt.fignum_exists(drawing_node.fig.number):
            plt.pause(0.1)
    except KeyboardInterrupt:
        pass
    finally:
        drawing_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()