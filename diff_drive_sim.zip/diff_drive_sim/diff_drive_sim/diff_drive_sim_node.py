import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped
from nav_msgs.msg import Odometry
from std_srvs.srv import Empty
from tf2_ros import TransformBroadcaster
from tf_transformations import quaternion_from_euler
from diff_drive_sim.kinematics import integrate_pose
import math

class DiffDriveSim(Node):
    def __init__(self):
        super().__init__('diff_drive_sim_node')
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.last_twist = Twist()
        
        # Parameters
        self.declare_parameter('publish_rate', 10.0)
        self.publish_rate = self.get_parameter('publish_rate').value
        
        # Publishers/Subscribers
        self.odom_pub = self.create_publisher(Odometry, '/odom', 10)
        self.cmd_vel_sub = self.create_subscription(Twist, '/cmd_vel', self.cmd_vel_cb, 10)
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # Service
        self.create_service(Empty, '/reset_pose', self.reset_cb)
        
        # Timer
        self.timer = self.create_timer(1.0/self.publish_rate, self.update)
        self.get_logger().info(f"Started simulation at {self.publish_rate}Hz")

    def cmd_vel_cb(self, msg):
        self.last_twist = msg

    def reset_cb(self, request, response):
        self.x, self.y, self.yaw = 0.0, 0.0, 0.0
        self.get_logger().info("Robot pose reset to origin (0,0,0)")
        return response

    def update(self):
        dt = 1.0 / self.publish_rate
        self.x, self.y, self.yaw = integrate_pose(
            self.x, self.y, self.yaw,
            self.last_twist.linear.x,
            self.last_twist.angular.z,
            dt
        )
        
        # Publish odometry
        odom = Odometry()
        odom.header.stamp = self.get_clock().now().to_msg()
        odom.header.frame_id = 'odom'
        odom.child_frame_id = 'base_link'
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        quat = quaternion_from_euler(0, 0, self.yaw)
        odom.pose.pose.orientation.x = quat[0]
        odom.pose.pose.orientation.y = quat[1]
        odom.pose.pose.orientation.z = quat[2]
        odom.pose.pose.orientation.w = quat[3]
        odom.twist.twist = self.last_twist
        self.odom_pub.publish(odom)
        
        # Publish transform
        t = TransformStamped()
        t.header.stamp = odom.header.stamp
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_link'
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0
        t.transform.rotation.x = quat[0]
        t.transform.rotation.y = quat[1]
        t.transform.rotation.z = quat[2]
        t.transform.rotation.w = quat[3]
        self.tf_broadcaster.sendTransform(t)

def main(args=None):
    rclpy.init(args=args)
    node = DiffDriveSim()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()