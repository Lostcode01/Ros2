import math

def integrate_pose(x, y, theta, v, omega, dt):
    """
    Integrate unicycle kinematics using Euler method
    
    Args:
        x: Current x position (m)
        y: Current y position (m)
        theta: Current orientation (rad)
        v: Linear velocity (m/s)
        omega: Angular velocity (rad/s)
        dt: Time step (s)
    
    Returns:
        New (x, y, theta) tuple
    """
    # Update orientation first
    theta_new = theta + omega * dt
    
    # Update position using new orientation
    x_new = x + v * math.cos(theta_new) * dt
    y_new = y + v * math.sin(theta_new) * dt
    
    return x_new, y_new, theta_new