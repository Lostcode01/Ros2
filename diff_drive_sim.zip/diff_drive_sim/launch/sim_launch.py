from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='diff_drive_sim',
            executable='diff_drive_sim_node',
            name='diff_drive_sim',
            parameters=[{'publish_rate': 10.0}]
        ),
        Node(
            package='diff_drive_sim',
            executable='drawing_node',
            name='drawing_node',
            output='screen'
        )
    ])