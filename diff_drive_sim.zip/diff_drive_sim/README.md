# Differential Drive Simulator with Drawing

This package simulates a differential-drive robot and visualizes its path like turtlesim.

## Setup Instructions (Ubuntu 22.04 + ROS 2 Humble)

```bash
# 1. Create workspace
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src

# 2. Copy this package folder here (diff_drive_sim)

# 3. Install dependencies
cd ~/ros2_ws
sudo apt update
sudo apt install -y python3-colcon-common-extensions python3-rosdep python3-matplotlib
sudo rosdep init
rosdep update
rosdep install --from-paths src --ignore-src -y

# 4. Build package
colcon build --packages-select diff_drive_sim

# 5. Source and run
source install/setup.bash
ros2 launch diff_drive_sim sim_launch.py