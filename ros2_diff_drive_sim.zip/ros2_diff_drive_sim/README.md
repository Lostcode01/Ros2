# ROS 2 Diff Drive Simulator - Minimal Version

## How to Run on Ubuntu 22.04 (ROS 2 Humble)

### 1. Setup workspace
```bash
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
git clone https://github.com/YOUR_USERNAME/diff_drive_sim.git  # OR copy this folder here
cd ..