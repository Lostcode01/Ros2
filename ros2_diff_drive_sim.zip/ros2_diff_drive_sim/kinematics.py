import math

def integrate_pose(x, y, theta, v, omega, dt):
    """Unicycle kinematics integration"""
    theta_new = theta + omega * dt
    x_new = x + v * math.cos(theta_new) * dt
    y_new = y + v * math.sin(theta_new) * dt
    return x_new, y_new, theta_new